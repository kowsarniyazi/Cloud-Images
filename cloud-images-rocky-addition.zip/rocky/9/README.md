# Rocky Linux 9 Cloud Image

Build a reusable Rocky Linux 9 GenericCloud Base QCOW2 image for KVM/OpenStack without resizing the original virtual disk. The build is based on the upstream **latest Rocky Linux 9** cloud image, so the point release can change between runs.

## Build host prerequisites

Ubuntu/Debian example:

```bash
sudo apt-get update
sudo apt-get install -y libguestfs-tools qemu-utils curl
```

Build from the `Cloud-Images` repository root:

```bash
chmod +x rocky/9/build.sh
sudo env WORK_DIR=/opt/images/rocky9 bash rocky/9/build.sh
```

The script downloads and verifies the official image, verifies required preinstalled packages (`cloud-init`, `qemu-guest-agent`, OpenSSH and growpart), applies the configuration in `config/`, selectively removes guest-specific state, and compresses the result. It refuses to overwrite existing working or final image files.

Output: `/opt/images/rocky9/rocky-9-cloud.qcow2` and its `.sha256` checksum. The source and working images remain in the work directory. Ensure sufficient free space and do not run against a disk in use by a VM.

## Validate

```bash
cd /opt/images/rocky9
sha256sum -c rocky-9-cloud.qcow2.sha256
qemu-img check rocky-9-cloud.qcow2
qemu-img info rocky-9-cloud.qcow2
```

## Guest credentials and security

The image contains **no preset root password**. Cloud-init and SSH are configured to allow direct root password login **only after** the provisioning system assigns a unique root password. For example, a trusted provisioning service may submit user-data like:

```yaml
#cloud-config
disable_root: false
ssh_pwauth: true
chpasswd:
  expire: false
  users:
    - name: root
      password: "REPLACE_WITH_UNIQUE_PASSWORD"
      type: text
```

Do not commit real passwords or sensitive user-data. Direct SSH login as root with passwords is higher risk; use strong per-VM credentials and appropriate firewall/rate-limiting policies. Check your platform's handling and retention of user-data.

The upstream image already includes the guest agent, but the hypervisor must expose an appropriate VirtIO channel. Always test the final VM boot, SSH login, networking, `cloud-init` completion, and QEMU Guest Agent connectivity before production rollout. The script does not perform a VM boot test.

## Files

- `build.sh` — image builder
- `config/99-cloud.cfg` — cloud-init override
- `config/01-root-login.conf` — SSH daemon drop-in

Upstream: https://dl.rockylinux.org/pub/rocky/9/images/x86_64/
