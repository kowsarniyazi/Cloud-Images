#!/usr/bin/env bash
# Build a Rocky Linux 9 GenericCloud QCOW2 image for OpenStack/KVM.
# No disk resize, embedded passwords, or SSH host keys.
set -Eeuo pipefail

readonly SOURCE_NAME='Rocky-9-GenericCloud-Base.latest.x86_64.qcow2'
readonly BASE_URL='https://dl.rockylinux.org/pub/rocky/9/images/x86_64'
readonly ORIGINAL='rocky9-original.qcow2'
readonly CHECKSUM_FILE='rocky9-original.CHECKSUM'
readonly WORKING='rocky9-working.qcow2'
readonly OUTPUT='rocky-9-cloud.qcow2'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK_DIR="${WORK_DIR:-$(pwd)}"
mkdir -p "$WORK_DIR"
cd "$WORK_DIR"
export LIBGUESTFS_BACKEND="${LIBGUESTFS_BACKEND:-direct}"

log() { printf '\n[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"; }
fail() { echo "ERROR: $*" >&2; exit 1; }
for cmd in curl sha256sum qemu-img virt-inspector virt-customize virt-sysprep virt-sparsify virt-cat awk grep mktemp; do
  command -v "$cmd" >/dev/null 2>&1 || fail "Missing command: $cmd"
done
[[ ${EUID} -eq 0 ]] || fail 'Run as root (libguestfs operations require appropriate privileges).'
[[ ! -e "$OUTPUT" ]] || fail "Output already exists: $OUTPUT (move or delete it before rebuilding)."
[[ ! -e "$WORKING" ]] || fail "Working image already exists: $WORKING (move it before rebuilding)."


log 'Downloading official Rocky Linux image/checksum (or reusing existing original)'
if [[ ! -s "$ORIGINAL" ]]; then
  curl --fail --location --retry 3 --output "$ORIGINAL.part" "$BASE_URL/$SOURCE_NAME"
  mv -- "$ORIGINAL.part" "$ORIGINAL"
fi
curl --fail --location --retry 3 --output "$CHECKSUM_FILE" "$BASE_URL/$SOURCE_NAME.CHECKSUM"
# Upstream uses: SHA256 (original-filename) = hex-digest
expected_sha="$(awk -v filename="$SOURCE_NAME" '$1 == "SHA256" && $2 == "(" filename ")" && $3 == "=" { print $4 }' "$CHECKSUM_FILE")"
[[ "$expected_sha" =~ ^[[:xdigit:]]{64}$ ]] || fail 'Could not parse upstream SHA256 checksum.'
printf '%s  %s\n' "$expected_sha" "$ORIGINAL" | sha256sum --check --status \
  || fail 'Upstream checksum does not match downloaded image!'
log 'SHA256 verified'

log 'Checking original QCOW2'
qemu-img check -f qcow2 "$ORIGINAL"
original_size="$(qemu-img info -f qcow2 --output=json "$ORIGINAL" | grep -o '"virtual-size"[[:space:]]*:[[:space:]]*[0-9]*' | head -1 | grep -o '[0-9]*$')"
[[ -n "$original_size" ]] || fail 'Could not determine original virtual disk size.'
cp --reflink=auto -- "$ORIGINAL" "$WORKING"

log 'Confirming required packages exist in the upstream cloud image'
package_report="$(virt-inspector -a "$WORKING")"
for package in cloud-init qemu-guest-agent openssh-server cloud-utils-growpart; do
  [[ "$package_report" == *"<name>$package</name>"* ]] \
    || fail "Upstream image is missing $package; aborting rather than silently changing packages."
done

log 'Installing cloud-init and SSH configuration from repository'
virt-customize -a "$WORKING" \
  --upload "$SCRIPT_DIR/config/99-cloud.cfg:/etc/cloud/cloud.cfg.d/99-cloud.cfg" \
  --upload "$SCRIPT_DIR/config/01-root-login.conf:/etc/ssh/sshd_config.d/01-root-login.conf"

log 'Verifying configuration files are present'
virt-cat -a "$WORKING" /etc/cloud/cloud.cfg.d/99-cloud.cfg | grep -qx 'disable_root: false' \
  || fail 'Expected cloud-init root configuration was not found.'
virt-cat -a "$WORKING" /etc/ssh/sshd_config.d/01-root-login.conf | grep -qx 'PermitRootLogin yes' \
  || fail 'Expected SSH root configuration was not found.'

log 'Cleaning machine identity, SSH host keys, leases, and logs'
virt-sysprep -a "$WORKING" \
  --operations machine-id,ssh-hostkeys,logfiles,dhcp-client-state,bash-history

log 'Compressing image (virtual disk size remains unchanged)'
virt-sparsify --compress "$WORKING" "$OUTPUT"

log 'Validating final image'
qemu-img check -f qcow2 "$OUTPUT"
final_size="$(qemu-img info -f qcow2 --output=json "$OUTPUT" | grep -o '"virtual-size"[[:space:]]*:[[:space:]]*[0-9]*' | head -1 | grep -o '[0-9]*$')"
[[ "$final_size" == "$original_size" ]] || fail 'Unexpected change in virtual disk size!'
virt-cat -a "$OUTPUT" /etc/cloud/cloud.cfg.d/99-cloud.cfg | grep -qx 'disable_root: false'
virt-cat -a "$OUTPUT" /etc/ssh/sshd_config.d/01-root-login.conf | grep -qx 'PermitRootLogin yes'
sha256sum "$OUTPUT" > "$OUTPUT.sha256"
sha256sum -c "$OUTPUT.sha256"
qemu-img info "$OUTPUT"
log "DONE: $WORK_DIR/$OUTPUT"
log 'IMPORTANT: Root account has no preset password. Provide a unique root password through cloud-init at provisioning time.'
log 'IMPORTANT: Boot-test SSH, cloud-init, networking, and guest agent before production use.'
